﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ZXing;
using ZXing.QrCode.Internal;
using ZXing.Rendering;
using static System.Runtime.CompilerServices.RuntimeHelpers;
using MySql.Data.MySqlClient;
using System.Deployment.Application;
using Excel = Microsoft.Office.Interop.Excel;
using System.Reflection;
using Microsoft.Office.Interop.Excel;

namespace RegForm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        MySqlConnection connection = new MySqlConnection("datasource=localhost;port=3306;username=root;password=");

        private void addToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string input = Interaction.InputBox("Add College", "", "");
            if (input != null)
            {
                ListViewItem item = new ListViewItem() { Text = input };
                listView1.Items.Add(item);
            }
        }

        private void removeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            foreach (ListViewItem item in listView1.SelectedItems)
            {
                item.Remove();
            }
        }

        private void qrGenerateToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (connection.State == ConnectionState.Open)
            {
                if (listView1.SelectedItems.Count == 1)
                {
                    try
                    {
                        byte[] key = SHA256Managed.Create().ComputeHash(Encoding.ASCII.GetBytes("1FXpxzQNpvoeZBMu5PXM"));
                        byte[] iv = new byte[16] { 0x7b, 0x20, 0x4b, 0x72, 0x79, 0x70, 0x74, 0x65, 0x78, 0x5f, 0x4f, 0x5f, 0x6f, 0x20, 0x7d, 0x00 };

                        string college = listView1.SelectedItems[0].Text.ToUpper();
                        string url = textBox4.Text;
                        string token = college + ":" + GetRandom(6) + ":" + "password";
                        MessageBox.Show(token);
                        token = Encryptor(Encoding.ASCII.GetBytes(token), key, iv);
                        string finalAccess = url + token;
                        var qr = GenerateQR(300, 300, finalAccess);
                       
                        string query = "INSERT INTO localapps.token (auth_token, auth_status) VALUES (?auth_token, ?auth_status);";

                        using (MySqlCommand cmd = new MySqlCommand(query, connection))
                        {
                            cmd.Parameters.Add("?auth_token", MySqlDbType.VarChar).Value = token;
                            cmd.Parameters.Add("?auth_status", MySqlDbType.VarChar).Value = "created";
                            cmd.ExecuteNonQuery();
                        }
                        textBox3.Text = finalAccess;
                        textBox2.Text = college;
                        pictureBox1.Image = qr;
                    }catch(Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                }
            }
            else
            {
                MessageBox.Show("Database not connected !");
            }
        }
        public static string Encryptor(byte[] cipherBytes, byte[] key, byte[] iv)
        {
            Aes encryptor = Aes.Create();
            encryptor.Mode = CipherMode.CBC;
            byte[] aesKey = new byte[32];
            Array.Copy(key, 0, aesKey, 0, 32);
            encryptor.Key = aesKey;
            encryptor.IV = iv;
            MemoryStream memoryStream = new MemoryStream();
            ICryptoTransform aesEncryptor = encryptor.CreateEncryptor();
            CryptoStream cryptoStream = new CryptoStream(memoryStream, aesEncryptor, CryptoStreamMode.Write);
            string output = null;
            try
            {
                cryptoStream.Write(cipherBytes, 0, cipherBytes.Length);
                cryptoStream.FlushFinalBlock();
                output = Convert.ToBase64String(memoryStream.ToArray(), 0, memoryStream.ToArray().Length);
            }
            finally
            {
                memoryStream.Close();
                cryptoStream.Close();
            }
            return output;
        }
        public static Random random = new Random();
        const string num = "012456789";
        public static string GetRandom(int len)
        {
            var sb = new StringBuilder();
            for (int i = 1; i <= new Random().Next(len, len + 5); i++)
            {
                var randomCharacterPosition = random.Next(0, num.Length);
                sb.Append(num[randomCharacterPosition]);
            }
            return sb.ToString();
        }
        public Bitmap GenerateQR(int width, int height, string text)
        {
            var bw = new ZXing.BarcodeWriter();

            var encOptions = new ZXing.Common.EncodingOptions
            {
                Width = width,
                Height = height,
                Margin = 0,
                PureBarcode = false
            };

            encOptions.Hints.Add(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.H);

            bw.Renderer = new BitmapRenderer();
            bw.Options = encOptions;
            bw.Format = ZXing.BarcodeFormat.QR_CODE;
            Bitmap bm = bw.Write(text);
            Bitmap overlay = new Bitmap("logo.png");

            int deltaHeigth = bm.Height - overlay.Height;
            int deltaWidth = bm.Width - overlay.Width;

            Graphics g = Graphics.FromImage(bm);
            g.DrawImage(overlay, new System.Drawing.Point(deltaWidth / 2, deltaHeigth / 2));

            return bm;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            if (Properties.Settings.Default.serverUrl != null)
            {
                textBox4.Text = Properties.Settings.Default.serverUrl;
            }
            if (Properties.Settings.Default.serverUrl != null)
            {
                textBox5.Text = Properties.Settings.Default.collegeListPath;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox4.Text != string.Empty)
            {
                Properties.Settings.Default.serverUrl = textBox4.Text;
                Properties.Settings.Default.Save();
            }

        }

        private async void button3_Click(object sender, EventArgs e)
        {
            await Task.Run(() =>
            {
                if (File.Exists(textBox5.Text))
                {
                    listView1.Items.Clear();
                    foreach (string line in File.ReadAllLines(textBox5.Text))
                    {
                        if (line != string.Empty)
                        {
                            ListViewItem item = new ListViewItem { Text = line };
                            listView1.Items.Add(item);
                        }
                    }
                    MessageBox.Show("Loaded !");
                }
            });
        }

        private async void button2_Click(object sender, EventArgs e)
        {
            if (textBox5.Text != string.Empty)
            {
                await Task.Run(() =>
                {
                    File.WriteAllText("CollegeList.txt", string.Empty);
                    foreach (ListViewItem item in listView1.Items)
                    {
                        File.AppendAllText("CollegeList.txt", item.Text + "\n");
                    }
                });
                Properties.Settings.Default.collegeListPath = textBox5.Text;
                Properties.Settings.Default.Save();
                MessageBox.Show("Saved !");
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                textBox5.Text = openFileDialog.FileName;
            }
        }
        private void button5_Click(object sender, EventArgs e)
        {
            try
            {
                MySqlDataAdapter adapter = new MySqlDataAdapter("SELECT * FROM localapps.registration", connection);
                DataSet ds = new DataSet();
                adapter.Fill(ds, "users");
                dataGridView1.DataSource = ds.Tables["users"];       
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if(connection.State != ConnectionState.Open)
            {
                button8.Enabled = true;
                button7.Enabled = false;
                connection.Open();
                MessageBox.Show("Connected !");
        
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (connection.State != ConnectionState.Closed)
            {
                button7.Enabled = true;
                button8.Enabled = false;
                connection.Close();
                MessageBox.Show("Disconnected !");
            }
         
        }

        private async void button6_Click(object sender, EventArgs e)
        {
            await Task.Run(() =>
            {
                Excel.Application excelApp = new Excel.Application();
                Excel.Workbook workbook = excelApp.Workbooks.Add(Missing.Value);
                Excel.Worksheet worksheet = (Excel.Worksheet)workbook.Sheets[1];
                int currentRow = 1;

                string[] columns = { "ID", "Name", "College", "Token" };
                for (int i = 0; i < columns.Count(); i++)
                {
                    worksheet.Cells[currentRow, i + 1] = columns[i];
                }
                currentRow++;

                /*  
                 foreach (DataRow row in dataTable.Rows)
                 {
                     currentRow++;
                     foreach (DataColumn column in dataTable.Columns)
                     {
                         worksheet.Cells[currentRow, column.Ordinal + 1] = row[column.ColumnName].ToString();
                     }
                 }

                string query = "SELECT column_name FROM mytable;";

                List<string> resultStrings = new List<string>();

                using (MySqlConnection connection = new MySqlConnection(connectionString))
                {
                    MySqlCommand command = new MySqlCommand(query, connection);
                    connection.Open();
                    using (MySqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            string resultString = reader.GetString(0);
                            resultStrings.Add(resultString);
                        }
                    }
                }
                */
                workbook.SaveAs(Path.Combine(Environment.CurrentDirectory, "example.xlsx"));
                workbook.Close();
                excelApp.Quit();
                MessageBox.Show("Done !");
            });
        }
    }
}
